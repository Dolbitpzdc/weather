# import pyowm
# 
# place = input('Input sity ')['place']
#
# def weather_1():
#     owm = pyowm.OWM("c6cfc1ad754846160c1e039cbda0e774")
#
#     mgr = owm.weather_manager()
#
#     observation = mgr.weather_at_place(place)
#
#     w = observation.weather
#
#     temp=w.temperature('celsius')['temp']
#
#     print("In sity  " + place + ' now ' + str(temp))
#
#
# print(weather_1())['weather_1']
