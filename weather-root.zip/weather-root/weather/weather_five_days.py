# import pyowm
#
# gorod = input('Выберите город'"\n")
#
# owm = pyowm.OWM("c6cfc1ad754846160c1e039cbda0e774")
#
# # print("В городе " + gorod + " сейчас " + str(temperature) + "°С")
#
# fc1 = owm .three_hours_forecast (gorod)
# f = fc1.get_forecast()
# for weather in f:
#       print (weather.get_reference_time('iso'),weather.get_status())
